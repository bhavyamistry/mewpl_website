<?php
defined('BASEPATH') OR exit('No direct script access allowed');

 class Film_master extends CI_Model
 {

 	public function __construct()
 	{
 		parent::__construct(); 		
 	}


 	public function insert_data($data)
 	{
		$products = $data['films'];
		$size = $data['size'];
		$date = date('Y-m-d H:i:s');
		$query="insert into master_films values('','$date','$products','$size','Active')";
		$this->db->query($query);		
 	}

 	public function get_recording()
 	{
 		$query=$this->db->query("select * from master_films");		
 		return $query->result();
 	}
 	
 
}
 	// public function save_records($name)
 	// {
 	// 	//$rt = 
 	// 	$$data = $arrayName = array('name' => $name);
 	// 	//$sql = "INSERT INTO testing values '$name'";
 	// 	$this->db->insert('testing',$data);
 	// }
?>