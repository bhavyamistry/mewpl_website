<?php
defined('BASEPATH') OR exit('No direct script access allowed');

 class Drs extends CI_Model
 {

 	public function __construct()
 	{
 		parent::__construct(); 		
 	}

 	public function get_records()
 	{
 		$this->db->select('product_name');
 		$query = $this->db->get('master_products');
 		return $query->result();
 	}
 	public function get_records2()
 	{
 		$this->db->select('size');
 		$query = $this->db->get('size_pro');
 		return $query->result();
 	}

 	public function insert_records($data)
 	{
 		$date = date("Y-m-d");
		$products = $data['products'];
		$size = $data['size'];
		$batch  = $data['batch'];
		$qty = $data['qty'];
		$crates = $data['crates'];
		$films = $data['films'];
		$clr = $data['clr'];
		$fat = $data['fat'];
		$snf = $data['snf'];
		$acidity = $data['acidity'];
		$mbrt = $data['mbrt'];
		$rate = $data['rate'];
		$neutralize = $data['neutralize'];
		$hydrogen_perox = $data['hydrogen_perox'];
		$detergent = $data['detergent'];
		$starch = $data['starch'];
		$urea = $data['urea'];
		$sugar = $data['sugar'];
		$boric_acid = $data['boric_acid'];
		$query="insert into add_procurement values('','$date','$products','$size','$batch','$qty','$crates','$films','$clr','$fat','$snf','$acidity','$mbrt','$rate','$neutralize','$hydrogen_perox','$detergent','$starch','$urea','$sugar','$boric_acid','Active')";
		$this->db->query($query);		
 	}
 
}
 	// public function save_records($name)
 	// {
 	// 	//$rt = 
 	// 	$$data = $arrayName = array('name' => $name);
 	// 	//$sql = "INSERT INTO testing values '$name'";
 	// 	$this->db->insert('testing',$data);
 	// }
 }
?>