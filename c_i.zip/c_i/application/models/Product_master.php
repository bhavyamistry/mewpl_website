<?php
defined('BASEPATH') OR exit('No direct script access allowed');

 class Product_master extends CI_Model
 {

 	public function __construct()
 	{
 		parent::__construct(); 		
 	}


 	public function insert_records($data)
 	{
		$products = $data['products'];
		$size = $data['size'];
		$date = date('Y-m-d H:i:s');
		$query="insert into master_products values('','$date','$products','$size','Active')";
		$this->db->query($query);		
 	}
 	public function get_record()
 	{
 		$query=$this->db->query("select * from master_products");		
 		return $query->result();
 	}
 
}
 	// public function save_records($name)
 	// {
 	// 	//$rt = 
 	// 	$$data = $arrayName = array('name' => $name);
 	// 	//$sql = "INSERT INTO testing values '$name'";
 	// 	$this->db->insert('testing',$data);
 	// }
?>