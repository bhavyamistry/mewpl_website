<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blog extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
		parent::__construct();		
		$this->load->model("Blogs");
		$this->load->database();
	}


	public function index()
	{	
			$result['data'] =$this->Blogs->get_records();
			$result['data2'] = $this->Blogs->get_records2();
			$this->form_validation->set_rules('date', 'Date', 'required');
			$this->load->view('Blog',$result);			
			// $this->load->view('Blog',$result);			
			if($this->input->post('save'))
			{	
				$arr = $arrayName = array('date' => $this->input->post('date'),
						'products' => $this->input->post('products'),
						'size' => $this->input->post('size'),
						'batch'  => $this->input->post('batch_num'),
						'qty' => $this->input->post('qty'),
						'crates' => $this->input->post('crates'),
						'films' => $this->input->post('films'),
						'clr' => $this->input->post('clr'),
						'fat' => $this->input->post('fat'),
						'snf' => $this->input->post('snf'),
						'acidity' => $this->input->post('acidity'),
						'mbrt' => $this->input->post('mbrt'),
						'rate' => $this->input->post('rate'),
						'neutralize' => $this->input->post('neutralizer'),
						'hydrogen_perox' => $this->input->post('hydrogen_peroxide'),
						'detergent' => $this->input->post('detergent'),
						'starch' => $this->input->post('starch'),
						'urea' => $this->input->post('urea'),
						'sugar' => $this->input->post('sugar'),
						'boric_acid' => $this->input->post('boric_acid'));
				$this->Blogs->insert_records($arr);
				echo "Records inserted succesfully";
			}

		// 		function isNumber(evt) {
  // evt = (evt) ? evt : window.event;
  // var charCode = (evt.which) ? evt.which : evt.keyCode;
  // if (charCode > 31 && (charCode < 48 || charCode > 57)) {
  //    return false;
  // }
			// if($this->input->post('save'))
			// {
			// 	$name = $this->input->post('f_name');
			// 	$this->Blogs->save_records($name);
			// 	echo "Records inserted successfully";
			// }
		}
		// public function check()
		// {
		// 	$pro = $this->input->post('products');
		// 	$
		// }
	
	// public function index()
	// {
	// 	$this->load->view('blog');
		
	// }

	
}
