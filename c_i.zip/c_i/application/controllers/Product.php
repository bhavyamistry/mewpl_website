<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
		parent::__construct();		
		$this->load->model("Product_master");
		$this->load->helper('url');
		$this->load->database();
		$result['data'] = $this->Product_master->get_record();
		$this->load->view('Product',$result);
	}


	public function index()
	{	
			
	}
			
	public function insert()
	{
		
		$arr = $arrayName = array('products' => $this->input->post('products'),
		'size' => $this->input->post('size'));
		$this->Product_master->insert_records($arr);
		echo "Records inserted succesfully";
		redirect(base_url().'index.php/Product');
			
	}

		// 		function isNumber(evt) {
  // evt = (evt) ? evt : window.event;
  // var charCode = (evt.which) ? evt.which : evt.keyCode;
  // if (charCode > 31 && (charCode < 48 || charCode > 57)) {
  //    return false;
  // }
			// if($this->input->post('save'))
			// {
			// 	$name = $this->input->post('f_name');
			// 	$this->Blogs->save_records($name);
			// 	echo "Records inserted successfully";
			// }
		}
		// public function check()
		// {
		// 	$pro = $this->input->post('products');
		// 	$
		// }
	
	// public function index()
	// {
	// 	$this->load->view('blog');
		
	// }

//