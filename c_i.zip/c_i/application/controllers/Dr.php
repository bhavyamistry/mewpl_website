<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dr extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	function __construct()
	{
		parent::__construct();		
		$this->load->model("Drs");
		$this->load->helper('url');
		$this->load->database();
		$result['data'] =$this->Drs->get_records();
		$result['data2'] = $this->Drs->get_records2();			
		$this->load->view('Dr',$result);			
	}


	public function index()
	{	
		
		
	}

// 	<?php
// 	$headers = array(
// 	    'Content-Type: application/json'
// 	);
// 	$ch = curl_init();
// 	curl_setopt($ch, CURLOPT_URL, "index.php/class/function");

// 	curl_setopt($ch, CURLOPT_POST, true);
// 	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
// 	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
// 	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

// 	$response = curl_exec($ch);
	
// 	print_r($response);

			// $this->load->view('Blog',$result);			
			// if($this->input->post('save'))
			// {	
			// 	$arr = $arrayName = array('date' => $this->input->post('date'),
			// 			'products' => $this->input->post('products'),
			// 			'size' => $this->input->post('size'),
			// 			'batch'  => $this->input->post('batch_num'),
			// 			'qty' => $this->input->post('qty'),
			// 			'crates' => $this->input->post('crates'),
			// 			'films' => $this->input->post('films'),
			// 			'clr' => $this->input->post('clr'),
			// 			'fat' => $this->input->post('fat'),
			// 			'snf' => $this->input->post('snf'),
			// 			'acidity' => $this->input->post('acidity'),
			// 			'mbrt' => $this->input->post('mbrt'),
			// 			'rate' => $this->input->post('rate'),
			// 			'neutralize' => $this->input->post('neutralizer'),
			// 			'hydrogen_perox' => $this->input->post('hydrogen_peroxide'),
			// 			'detergent' => $this->input->post('detergent'),
			// 			'starch' => $this->input->post('starch'),
			// 			'urea' => $this->input->post('urea'),
			// 			'sugar' => $this->input->post('sugar'),
			// 			'boric_acid' => $this->input->post('boric_acid'));
			// 	$this->Drs->insert_records($arr);
			// 	echo "Records inserted succesfully";
			// 	// redirect(base_url('application/controllers/').'Dashboard.php');
			// }

		// 		function isNumber(evt) {
  // evt = (evt) ? evt : window.event;
  // var charCode = (evt.which) ? evt.which : evt.keyCode;
  // if (charCode > 31 && (charCode < 48 || charCode > 57)) {
  //    return false;
  // }
			// if($this->input->post('save'))
			// {
			// 	$name = $this->input->post('f_name');
			// 	$this->Blogs->save_records($name);
			// 	echo "Records inserted successfully";
			// }
		
		public function insert()
		{
			$result['data'] =$this->Drs->get_records();
			$result['data2'] = $this->Drs->get_records2();					
			$date = date('Y-m-d H:i:s');
			$this->load->view('Dr',$result);			
			if($this->input->post('save'))
			{	
				$arr = $arrayName = array('date' => $date,
						'products' => $this->input->post('products'),
						'size' => $this->input->post('size'),
						'batch'  => $this->input->post('batch_num'),
						'qty' => $this->input->post('qty'),
						'crates' => $this->input->post('crates'),
						'films' => $this->input->post('films'),
						'clr' => $this->input->post('clr'),
						'fat' => $this->input->post('fat'),
						'snf' => $this->input->post('snf'),
						'acidity' => $this->input->post('acidity'),
						'mbrt' => $this->input->post('mbrt'),
						'rate' => $this->input->post('rate'),
						'neutralize' => $this->input->post('neutralizer'),
						'hydrogen_perox' => $this->input->post('hydrogen_peroxide'),
						'detergent' => $this->input->post('detergent'),
						'starch' => $this->input->post('starch'),
						'urea' => $this->input->post('urea'),
						'sugar' => $this->input->post('sugar'),
						'boric_acid' => $this->input->post('boric_acid'));
				$this->Drs->insert_records($arr);
				echo "Records inserted succesfully";
				echo $date;
				redirect(base_url()."index.php/Dr","refresh");

			}
		}
		


		// public function check()
		// {
		// 	$pro = $this->input->post('products');
		// 	$
		// }
	
	// public function index()
	// {
	// 	$this->load->view('blog');
		
	// }

	
}

//