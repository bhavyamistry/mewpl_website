<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Film extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
		parent::__construct();		
		$this->load->model("Film_master");
		$this->load->helper('url');
		$this->load->database();
		$result['data'] = $this->Film_master->get_recording();
		$this->load->view('Film',$result);
	}


	public function index()
	{	
		// $result['data'] =$this->Drs->get_records();
		// $result['data2'] = $this->Drs->get_records2();			
		// $this->load->view('Dr',$result);
		
			// if($this->input->post('save'))
			// {	
			// 	$arr = $arrayName = array('films' => $this->input->post('films'),
			// 			'size' => $this->input->post('size'));
			//   	$this->Film_master->insert_data($arr);
			//  	echo "Records inserted succesfully";
			// // 	redirect(base_url('application/controllers/').'Dashboard.php');
			// }

		// 		function isNumber(evt) {
  // evt = (evt) ? evt : window.event;
  // var charCode = (evt.which) ? evt.which : evt.keyCode;
  // if (charCode > 31 && (charCode < 48 || charCode > 57)) {
  //    return false;
  // }
			// if($this->input->post('save'))
			// {
			// 	$name = $this->input->post('f_name');
			// 	$this->Blogs->save_records($name);
			// 	echo "Records inserted successfully";
			// }
	}
	public function inserting()
	{
		$arr = $arrayName = array('films' => $this->input->post('films'),'size' => $this->input->post('size'));
		$this->Film_master->insert_data($arr);
		echo "Records inserted succesfully";
		Redirect(base_url().'index.php/Film');
			
	}
		// public function Dash()
		// {
		// 	$this->load->view("Dashboard");
		// }
		// public function check()
		// {
		// 	$pro = $this->input->post('products');
		// 	$
		// }
	
	// public function index()
	// {
	// 	$this->load->view('blog');
		
	// }
}

//