<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<!-- BEGIN HEAD -->
<head>
    <meta charset="UTF-8">
    <title>DRNQ</title>

    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>libs/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/fonts/line-awesome/css/line-awesome.min.css">
    <!--<link rel="stylesheet" type="text/css" href="assets/fonts/open-sans/styles.css">-->

    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/fonts/montserrat/styles.css">

    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>libs/tether/css/tether.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>libs/jscrollpane/jquery.jscrollpane.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>libs/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/styles/common.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/styles/customStyle.css">
    <!-- END GLOBAL MANDATORY STYLES -->

    <!-- BEGIN THEME STYLES -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/styles/themes/primary.min.css">
    <link class="ks-sidebar-dark-style" rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/styles/themes/sidebar-black.min.css">
    <!-- END THEME STYLES -->

<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/fonts/kosmo/styles.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/fonts/weather/css/weather-icons.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>libs/c3js/c3.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>libs/noty/noty.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/styles/widgets/payment.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/styles/widgets/panels.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/styles/dashboard/tabbed-sidebar.min.css">
</head>
<!-- END HEAD -->

<body class="ks-navbar-fixed ks-sidebar-empty ks-sidebar-position-fixed ks-page-header-fixed ks-theme-primary ks-page-loading"> <!-- remove ks-page-header-fixed to unfix header -->





    <!-- BEGIN HEADER -->
<nav class="navbar ks-navbar">
    <!-- BEGIN HEADER INNER -->
    <!-- BEGIN LOGO -->
    <div href="index.html" class="navbar-brand">
        <!-- BEGIN RESPONSIVE SIDEBAR TOGGLER -->
        <a href="#" class="ks-sidebar-toggle"><i class="ks-icon la la-bars" aria-hidden="true"></i></a>
        <a href="#" class="ks-sidebar-mobile-toggle"><i class="ks-icon la la-bars" aria-hidden="true"></i></a>
        <!-- END RESPONSIVE SIDEBAR TOGGLER -->

        <div class="ks-navbar-logo">
            <a href="index.html" class="ks-logo"><img src="<?php echo base_url('assest/'); ?>assets/img/logo.png"></a>
        </div>
    </div>
    <!-- END LOGO -->

    <!-- BEGIN MENUS -->
    <div class="ks-wrapper">
        <nav class="nav navbar-nav">

            <!-- BEGIN NAVBAR ACTIONS -->
            <div class="ks-navbar-actions">

                <!-- BEGIN NAVBAR USER -->
                <div class="nav-item dropdown ks-user">
                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                        <span class="ks-avatar">
                            <img src="<?php echo base_url('assest/'); ?>assets/img/avatars/avatar-13.jpg" width="36" height="36">
                        </span>
                        <span class="ks-info">
                            <span class="ks-name">Robert Dean</span>
                            <span class="ks-description">Premium User</span>
                        </span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="Preview">
                        <a class="dropdown-item" href="#">
                            <span class="la la-user ks-icon"></span>
                            <span>Profile</span>
                        </a>
                        <a class="dropdown-item" href="#">
                            <span class="la la-sign-out ks-icon" aria-hidden="true"></span>
                            <span>Logout</span>
                        </a>
                    </div>
                </div>
                <!-- END NAVBAR USER -->
            </div>
            <!-- END NAVBAR ACTIONS -->
        </nav>

        <!-- BEGIN NAVBAR ACTIONS TOGGLER -->
        <nav class="nav navbar-nav ks-navbar-actions-toggle">
            <a class="nav-item nav-link" href="#">
                <span class="la la-ellipsis-h ks-icon ks-open"></span>
                <span class="la la-close ks-icon ks-close"></span>
            </a>
        </nav>
        <!-- END NAVBAR ACTIONS TOGGLER -->

        <!-- BEGIN NAVBAR MENU TOGGLER -->
        <nav class="nav navbar-nav ks-navbar-menu-toggle">
            <a class="nav-item nav-link" href="#">
                <span class="la la-th ks-icon ks-open"></span>
                <span class="la la-close ks-icon ks-close"></span>
            </a>
        </nav>
        <!-- END NAVBAR MENU TOGGLER -->
    </div>
    <!-- END MENUS -->
    <!-- END HEADER INNER -->
</nav>
<!-- END HEADER -->

<!-- BEGIN NAVBAR HORIZONTAL ICONBAR -->
<div class="ks-navbar-horizontal ks-icons-top ks-info">
    <ul class="nav nav-pills">
        <li class="nav-item">
            <a class="nav-link active" href="<?php echo base_url();?>">
                <span class="ks-icon la la-dashboard"></span>
                <span class="ks-text">Dashboard</span>
            </a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                <span class="ks-icon la la-dashboard"></span>
                <span class="ks-text">Masters</span>
            </a>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="<?php echo base_url().'index.php/Product';?>">Products</a>
                <a class="dropdown-item" href="<?php echo base_url().'index.php/Film'?>">Films</a>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">
                <span class="ks-icon la la-flask"></span>
                <span class="ks-text">Users</span>
            </a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                <span class="ks-icon la la-dashboard"></span>
                <span class="ks-text">Inventory</span>
            </a>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="inventory-films.html">Films</a>
                <a class="dropdown-item" href="inventory-crate.html">Crate</a>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="report.html">
                <span class="ks-icon la la-flask"></span>
                <span class="ks-text">Reports</span>
            </a>
        </li>
        
    </ul>
</div>
<!-- END NAVBAR HORIZONTAL ICONBAR -->


<div class="ks-page-container ks-dashboard-tabbed-sidebar-fixed-tabs">
    <div class="ks-column ks-page">
        <div class="ks-page-header">
            <!-- <section class="ks-title-and-subtitle">
                <div class="ks-title-block">
                    <h3 class="ks-main-title">Dashboard</h3>
                    <div class="ks-sub-title">This is header sub title</div>
                </div>
            </section> -->
            <nav aria-label="breadcrumb">
                <h3 class="ks-main-title">Dashboard</h3>
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url()?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
              </ol>
            </nav>
        </div>

        <div class="ks-page-content">
            <div class="ks-page-content-body">
                <div class="ks-dashboard-tabbed-sidebar">
                    <div class="ks-dashboard-tabbed-sidebar-widgets">
                        <div class="row">
                            <div class="col-lg-3 col-md-6">
                                <a href="<?php echo base_url().'index.php/Dp'?>" style="color: inherit;">
                                    <div class="card ks-widget-payment-simple-amount-item ks-purple">
                                        <div class="payment-simple-amount-item-icon-block">
                                            <span class="ks-icon-combo-chart ks-icon"></span>
                                        </div>

                                        <div class="payment-simple-amount-item-body">
                                            <div class="payment-simple-amount-item-amount">
                                                <span class="ks-amount">33</span>
                                            </div>
                                            <div class="payment-simple-amount-item-description">
                                                Daily Procurement
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <a href="#" style="color: inherit;">
                                    <div class="card ks-widget-payment-simple-amount-item ks-green">
                                        <div class="payment-simple-amount-item-icon-block">
                                            <span class="la la-pie-chart ks-icon"></span>
                                        </div>

                                        <div class="payment-simple-amount-item-body">
                                            <div class="payment-simple-amount-item-amount">
                                                <span class="ks-amount">1024</span>
                                            </div>
                                            <div class="payment-simple-amount-item-description">
                                                Films
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <a href="#" style="color: inherit;">
                                    <div class="card ks-widget-payment-simple-amount-item ks-pink">
                                        <div class="payment-simple-amount-item-icon-block">
                                            <span class="ks-icon-user ks-icon"></span>
                                        </div>

                                        <div class="payment-simple-amount-item-body">
                                            <div class="payment-simple-amount-item-amount">
                                                <span class="ks-amount">145</span>
                                            </div>
                                            <div class="payment-simple-amount-item-description">
                                                Crats
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <a href="#" style="color: inherit;">
                                    <div class="card ks-widget-payment-simple-amount-item ks-orange">
                                        <div class="payment-simple-amount-item-icon-block">
                                            <span class="la la-area-chart ks-icon"></span>
                                        </div>

                                        <div class="payment-simple-amount-item-body">
                                            <div class="payment-simple-amount-item-amount">
                                                <span class="ks-amount">15</span>
                                            </div>
                                            <div class="payment-simple-amount-item-description">
                                                Report
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card ks-card-widget ks-widget-table">
                                    <h5 class="card-header">
                                         Daily Procurement 

                                        <div class="ks-controls">
                                            <a href="<?php echo base_url().'index.php/Dp'?>" class="ks-control-link">View All</a>
                                        </div>
                                    </h5>
                                    <div class="card-block">
                                        <table class="table ks-payment-table-invoicing">
                                            <tr>
                                                <th>Date</th>
                                                <th>Product</th>
                                                <th>Qty</th>
                                                <th>Crates</th>
                                                <th>CLR</th>
                                                <th>Aciditity</th>
                                            </tr>
                                            <tr>
                                                <td>June 21, 2019</td>
                                                <td>500 Ml</td>
                                                <td>80</td>
                                                <td>7</td>
                                                <td>FAT</td>
                                                <td>MBRT (Hr)</td>
                                            </tr>
                                            <tr>
                                                <td>June 21, 2019</td>
                                                <td>500 Ml</td>
                                                <td>80</td>
                                                <td>7</td>
                                                <td>FAT</td>
                                                <td>MBRT (Hr)</td>
                                            </tr>
                                            <tr>
                                                <td>June 21, 2019</td>
                                                <td>500 Ml</td>
                                                <td>80</td>
                                                <td>7</td>
                                                <td>FAT</td>
                                                <td>MBRT (Hr)</td>
                                            </tr>
                                            <tr>
                                                <td>June 21, 2019</td>
                                                <td>500 Ml</td>
                                                <td>80</td>
                                                <td>7</td>
                                                <td>FAT</td>
                                                <td>MBRT (Hr)</td>
                                            </tr>
                                            <tr>
                                                <td>June 21, 2019</td>
                                                <td>500 Ml</td>
                                                <td>80</td>
                                                <td>7</td>
                                                <td>FAT</td>
                                                <td>MBRT (Hr)</td>
                                            </tr>
                                            <tr>
                                                <td>June 21, 2019</td>
                                                <td>500 Ml</td>
                                                <td>80</td>
                                                <td>7</td>
                                                <td>FAT</td>
                                                <td>MBRT (Hr)</td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<a href="<?php echo site_url().'/Dashboard/master_pro';?>"><?php echo site_url().'/Dashboard/master_pro';?></a>

<!-- BEGIN PAGE LEVEL PLUGINS -->
<script src="<?php echo base_url('assest/'); ?>libs/jquery/jquery.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/popper/popper.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/responsejs/response.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/loading-overlay/loadingoverlay.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/tether/js/tether.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/jscrollpane/jquery.jscrollpane.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/jscrollpane/jquery.mousewheel.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/flexibility/flexibility.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/noty/noty.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/velocity/velocity.min.js"></script>
<!-- END PAGE LEVEL PLUGINS -->

<!-- BEGIN THEME LAYOUT SCRIPTS -->
<script src="<?php echo base_url('assest/'); ?>assets/scripts/common.min.js"></script>
<!-- END THEME LAYOUT SCRIPTS -->

<script src="<?php echo base_url('assest/'); ?>libs/d3/d3.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/c3js/c3.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/noty/noty.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/maplace/maplace.min.js"></script>
<script src="https://maps.google.com/maps/api/js?libraries=geometry&v=3.26&key=AIzaSyBBjLDxcCjc4s9ngpR11uwBWXRhyp3KPYM"></script>
<script type="application/javascript">
(function ($) {
    $(document).ready(function () {
        c3.generate({
            bindto: '#ks-next-payout-chart',
            data: {
                columns: [
                    ['data1', 6, 5, 6, 5, 7, 8, 7]
                ],
                types: {
                    data1: 'area'
                },
                colors: {
                    data1: '#81c159'
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                show: false
            },
            point: {
                show: false
            },
            axis: {
                x: {show:false},
                y: {show:false}
            }
        });

        c3.generate({
            bindto: '#ks-total-earning-chart',
            data: {
                columns: [
                    ['data1', 6, 5, 6, 5, 7, 8, 7]
                ],
                types: {
                    data1: 'area'
                },
                colors: {
                    data1: '#4e54a8'
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                show: false
            },
            point: {
                show: false
            },
            axis: {
                x: {show:false},
                y: {show:false}
            }
        });

        c3.generate({
            bindto: '.ks-chart-orders-block',
            data: {
                columns: [
                    ['Revenue', 150, 200, 220, 280, 400, 160, 260, 400, 300, 400, 500, 420, 500, 300, 200, 100, 400, 600, 300, 360, 600],
                    ['Profit', 350, 300,  200, 140, 200, 30, 200, 100, 400, 600, 300, 200, 100, 50, 200, 600, 300, 500, 30, 200, 320]
                ],
                colors: {
                    'Revenue': '#f88528',
                    'Profit': '#81c159'
                }
            },
            point: {
                r: 5
            },
            grid: {
                y: {
                    show: true
                }
            }
        });

        // setTimeout(function () {
        //     new Noty({
        //         text: '<strong>Welcome to Kosmo Admin Template</strong>! <br> You successfully read this important alert message.',
        //         type   : 'information',
        //         theme  : 'mint',
        //         layout : 'topRight',
        //         timeout: 3000
        //     }).show();
        // }, 1500);

        var maplace = new Maplace({
            map_div: '#ks-payment-widget-table-and-map-map',
            controls_on_map: false
        });
        maplace.Load();
    });
})(jQuery);
</script>

<div class="ks-mobile-overlay"></div>

</body>
</html>