<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<!-- BEGIN HEAD -->
<head>
    <meta charset="UTF-8">
    <title>DRNQ</title>

    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>libs/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/fonts/line-awesome/css/line-awesome.min.css">
    <!--<link rel="stylesheet" type="text/css" href="assets/fonts/open-sans/styles.css">-->

    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/fonts/montserrat/styles.css">

    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>libs/tether/css/tether.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>libs/jscrollpane/jquery.jscrollpane.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>libs/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/styles/common.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/styles/customStyle.css">
    <!-- END GLOBAL MANDATORY STYLES -->

    <!-- BEGIN THEME STYLES -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/styles/themes/primary.min.css">
    <link class="ks-sidebar-dark-style" rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/styles/themes/sidebar-black.min.css">
    <!-- END THEME STYLES -->

<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/fonts/kosmo/styles.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/fonts/weather/css/weather-icons.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>libs/c3js/c3.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>libs/noty/noty.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/styles/widgets/payment.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/styles/widgets/panels.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/styles/dashboard/tabbed-sidebar.min.css">

<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>libs/select2/css/select2.min.css"> <!-- Original -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/styles/libs/select2/select2.min.css"> <!-- Customization -->

<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>libs/prism/prism.css"> <!-- original -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>libs/flatpickr/flatpickr.min.css"> <!-- original -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/'); ?>assets/styles/libs/flatpickr/flatpickr.min.css"> <!-- customization -->
</head>
<!-- END HEAD -->

<body class="ks-navbar-fixed ks-sidebar-empty ks-sidebar-position-fixed ks-page-header-fixed ks-theme-primary ks-page-loading"> <!-- remove ks-page-header-fixed to unfix header -->





    <!-- BEGIN HEADER -->
<nav class="navbar ks-navbar">
    <!-- BEGIN HEADER INNER -->
    <!-- BEGIN LOGO -->
    <div href="index.html" class="navbar-brand">
        <!-- BEGIN RESPONSIVE SIDEBAR TOGGLER -->
        <!-- END RESPONSIVE SIDEBAR TOGGLER -->

        <div class="ks-navbar-logo">
            <a href="index.html" class="ks-logo"><img src="<?php echo base_url('assest/'); ?>assets/img/logo.png"></a>
        </div>
    </div>
    <!-- END LOGO -->

    <!-- BEGIN MENUS -->
    <div class="ks-wrapper">
        <nav class="nav navbar-nav">

            <!-- BEGIN NAVBAR ACTIONS -->
            <div class="ks-navbar-actions">

                <!-- BEGIN NAVBAR USER -->
                <div class="nav-item dropdown ks-user">
                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                        <span class="ks-avatar">
                            <img src="<?php echo base_url('assest/'); ?>assets/img/avatars/avatar-13.jpg" width="36" height="36">
                        </span>
                        <span class="ks-info">
                            <span class="ks-name">Robert Dean</span>
                            <span class="ks-description">Premium User</span>
                        </span>
                    </a>                    
                </div>
                <!-- END NAVBAR USER -->
            </div>
            <!-- END NAVBAR ACTIONS -->
        </nav>

        <!-- BEGIN NAVBAR ACTIONS TOGGLER -->
        <!-- <nav class="nav navbar-nav ks-navbar-actions-toggle">
            <a class="nav-item nav-link" href="#">
                <span class="la la-ellipsis-h ks-icon ks-open"></span>
                <span class="la la-close ks-icon ks-close"></span>
            </a>
        </nav> -->
        <!-- END NAVBAR ACTIONS TOGGLER -->

        <!-- BEGIN NAVBAR MENU TOGGLER -->
        
        <!-- END NAVBAR MENU TOGGLER -->
    </div>
    <!-- END MENUS -->
    <!-- END HEADER INNER -->
</nav>
<!-- END HEADER -->

<!-- BEGIN NAVBAR HORIZONTAL ICONBAR -->
<div class="ks-navbar-horizontal ks-icons-top ks-info">
    <ul class="nav nav-pills">
        <li class="nav-item">
            <a class="nav-link active" url="<?php echo base_url();?>">
                <span class="ks-icon la la-dashboard"></span>
                <span class="ks-text">Dashboard</span>
            </a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                <span class="ks-icon la la-dashboard"></span>
                <span class="ks-text">Masters</span>
            </a>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="<?php echo base_url().'index.php/Product';?>">Products</a>
                <a class="dropdown-item" href="<?php echo base_url().'index.php/Film';?>">Films</a>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">
                <span class="ks-icon la la-flask"></span>
                <span class="ks-text">Users</span>
            </a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                <span class="ks-icon la la-dashboard"></span>
                <span class="ks-text">Inventory</span>
            </a>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="inventory-films.html">Films</a>
                <a class="dropdown-item" href="inventory-crate.html">Crate</a>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="report.html">
                <span class="ks-icon la la-flask"></span>
                <span class="ks-text">Reports</span>
            </a>
        </li>
        
    </ul>
</div>
<!-- END NAVBAR HORIZONTAL ICONBAR -->


<div class="ks-page-container ks-dashboard-tabbed-sidebar-fixed-tabs">
    <div class="ks-column ks-page">
        <div class="ks-page-header">
            <!-- <section class="ks-title-and-subtitle">
                <div class="ks-title-block">
                    <h3 class="ks-main-title">Dashboard</h3>
                    <div class="ks-sub-title">This is header sub title</div>
                </div>
            </section> -->
            <nav aria-label="breadcrumb">
                <h3 class="ks-main-title">Add Daily Report</h3>
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url();?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo base_url().'index.php/Dp';?>">Daily Procurement</a></li>
                <li class="breadcrumb-item active" aria-current="page">Add Daily Report</li>
              </ol>
            </nav>
        </div>

        <div class="ks-page-content">
            <div class="ks-page-content-body">
                <div class="ks-nav-body-wrapper addDailyReport-page">
                    <div class="container-fluid ks-rows-section">
                        <div class="ks-header">
                        </div>

                        <div class="row">
                            <div class="col-lg-12 ks-panels-column-section">
                                <div class="card">
                                    <div class="card-block">
                                <form method="POST" action="<?php echo base_url().'index.php/Dr/insert'?>"> 
                                          <div class="form-row">
                                            <div class="form-group col-md-2">
                                              <label for="inputEmail4">Date</label>
                                              <input class="form-control" placeholder="Date" name="date" value="<?php echo date("Y-m-d")?>" readonly>
                                            </div>
                                            <div class="col-sm-12"></div>
                                            <div class="form-group col-md-2">
                                              <label for="inputPassword4">Product</label>
                                              <select id="inputState" class="form-control" name="products" required>
                                              <option value="" disabled="" selected>Select</option>
                                              <?php
                                                  $i=1;
                                                  foreach($data as $row)
                                                  {
                                                  echo "<option value='".$row->product_name."'>".$row->product_name."</option>";
                                                  $i++;
                                                  }
                                                ?>                                                
                                              </select>
                                            </div>
                                            <div class="form-group col-md-1">
                                              <label for="inputPassword4">Size</label>
                                              <select id="inputState" class="form-control" name="size" required>
                                              <option value="" disabled="" selected>Select</option>
                                              <?php
                                                  $i=1;
                                                  foreach($data2 as $row)
                                                  {
                                                    echo "<option value='".$row->size."'>".$row->size."</option>";
                                                    $i++;
                                                  }
                                                ?>                                                
                                              </select>
                                            </div>
                                            <div class="form-group col-md-2">
                                              <label for="inputPassword4">Batch Number</label>
                                              <input type="text" class="form-control" id="inputPassword4" placeholder="Batch Number" name="batch_num" required>
                                            </div>
                                            <div class="form-group col-md-1">
                                              <label for="inputPassword4">Qty</label>
                                              <input type="number" class="form-control" id="inputPassword4" placeholder="Qty" name="qty" min="0" required>
                                            </div>

                                            <div class="col-sm-12"></div>
                                            <div class="form-group col-md-1">
                                              <label for="inputPassword4">Crates</label>
                                              <input type="number" name="crates" min="0" class="form-control" id="inputPassword4" placeholder="Crates" required>
                                            </div>
                                            <div class="form-group col-md-1">
                                              <label for="inputPassword4">Film Used</label>
                                              <input type="number" name="films" min="0" class="form-control" id="inputPassword4" placeholder="Film Used" required>
                                            </div>
                                            <div class="form-group col-md-1">
                                              <label for="inputPassword4">CLR</label>
                                              <input type="number" name="clr" min="0" class="form-control" id="inputPassword4" placeholder="CLR" required>
                                            </div>
                                            <div class="form-group col-md-1">
                                              <label for="inputPassword4">FAT</label>
                                              <input type="number" name="fat" min="0" class="form-control" id="inputPassword4" placeholder="FAT" required>
                                            </div>
                                            <div class="form-group col-md-1">
                                              <label for="inputPassword4">SNF</label>
                                              <input type="number" name="snf" min="0" class="form-control" id="inputPassword4" placeholder="SNF" required>
                                            </div>
                                            <div class="form-group col-md-1">
                                              <label for="inputPassword4">Aciditity</label>
                                              <input type="number" name="acidity" min="0" class="form-control" id="inputPassword4" placeholder="Aciditity" required>
                                            </div>
                                            <div class="form-group col-md-1">
                                              <label for="inputPassword4">MBRT (Hr)</label>
                                              <input  type="number" name="mbrt" min="0" class="form-control" id="inputPassword4" placeholder="MBRT (Hr)" required>
                                            </div>
                                            <div class="form-group col-md-1">
                                              <label for="inputPassword4">Rate</label>
                                              <input type="number" name="rate" min="0" class="form-control" id="inputPassword4" placeholder="Rate" required>
                                            </div>
                                          </div>

                                        <div class="form-row" style="margin-top: 30px;">
                                            <div class="form-group col-md-2">
                                                <h5 class="card-title">Adutleration Test</h5>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-1">
                                              <label for="inputState">Neutalizer</label>
                                              <select id="inputState" class="form-control" name="neutralizer" required>
                                                <option disabled="" selected>Select</option>
                                                <option value="+VE">+VE</option>
                                                <option value="_VE">_VE</option>
                                              </select>
                                            </div>
                                            <div class="form-group col-md-2">
                                              <label for="inputState">Hydrogen Peroxide</label>
                                              <select id="inputState" class="form-control" name="hydrogen_peroxide" required>
                                                <option disabled="" selected>Select</option>
                                                <option value="+VE">+VE</option>
                                                <option value="_VE">_VE</option>
                                              </select>
                                            </div>
                                            <div class="form-group col-md-2">
                                              <label for="inputState">Detergent / Pulverised </label>
                                              <select id="inputState" class="form-control" name="detergent" required>
                                                <option disabled="" selected>Select</option>
                                                <option value="+VE">+VE</option>
                                                <option value="_VE">_VE</option>
                                              </select>
                                            </div>
                                            <div class="form-group col-md-1">
                                              <label for="inputState">Starch </label>
                                              <select id="inputState" class="form-control" name="starch" required>
                                                <option disabled="" selected>Select</option>
                                                <option value="+VE">+VE</option>
                                                <option value="_VE">_VE</option>
                                              </select>
                                            </div>
                                            <div class="form-group col-md-1">
                                              <label for="inputState">Urea  </label>
                                              <select id="inputState" class="form-control" name="urea" required>
                                                <option disabled="" selected>Select</option>
                                                <option value="+VE">+VE</option>
                                                <option value="_VE">_VE</option>
                                              </select>
                                            </div>
                                            <div class="form-group col-md-1">
                                              <label for="inputState">Sugar </label>
                                              <select id="inputState" class="form-control" name="sugar" required>
                                                <option disabled="" selected>Select</option>
                                                <option value="+VE">+VE</option>
                                                <option value="_VE">_VE</option>
                                              </select>
                                            </div>
                                            <div class="form-group col-md-1">
                                              <label for="inputState">Boric Acid </label>
                                              <select id="inputState" class="form-control" name="boric_acid" required>
                                                <option disabled="" selected>Select</option>
                                                <option value="+VE">+VE</option>
                                                <option value="_VE">_VE</option>
                                              </select>
                                            </div>
                                        </div>
                                        <input type="submit" class="btn btn-primary" name="save">
                                </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- BEGIN PAGE LEVEL PLUGINS -->
<script src="<?php echo base_url('assest/'); ?>libs/jquery/jquery.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/popper/popper.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/responsejs/response.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/loading-overlay/loadingoverlay.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/tether/js/tether.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/jscrollpane/jquery.jscrollpane.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/jscrollpane/jquery.mousewheel.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/flexibility/flexibility.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/noty/noty.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/velocity/velocity.min.js"></script>
<!-- END PAGE LEVEL PLUGINS -->

<!-- BEGIN THEME LAYOUT SCRIPTS -->
<script src="<?php echo base_url('assest/'); ?>assets/scripts/common.min.js"></script>
<!-- END THEME LAYOUT SCRIPTS -->
<script src="<?php echo base_url('assest/'); ?>libs/select2/js/select2.min.js"></script>

<script src="<?php echo base_url('assest/'); ?>libs/flatpickr/flatpickr.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/prism/prism.js"></script>
<script type="application/javascript">
(function ($) {
    $(document).ready(function() {
        $('.flatpickr').flatpickr();
    });
})(jQuery);
</script>

<script src="<?php echo base_url('assest/'); ?>libs/d3/d3.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/c3js/c3.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/noty/noty.min.js"></script>
<script src="<?php echo base_url('assest/'); ?>libs/maplace/maplace.min.js"></script>
<script src="https://maps.google.com/maps/api/js?libraries=geometry&v=3.26&key=AIzaSyBBjLDxcCjc4s9ngpR11uwBWXRhyp3KPYM"></script>
<script type="application/javascript">
(function ($) {
    $(document).ready(function () {
        c3.generate({
            bindto: '#ks-next-payout-chart',
            data: {
                columns: [
                    ['data1', 6, 5, 6, 5, 7, 8, 7]
                ],
                types: {
                    data1: 'area'
                },
                colors: {
                    data1: '#81c159'
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                show: false
            },
            point: {
                show: false
            },
            axis: {
                x: {show:false},
                y: {show:false}
            }
        });

        c3.generate({
            bindto: '#ks-total-earning-chart',
            data: {
                columns: [
                    ['data1', 6, 5, 6, 5, 7, 8, 7]
                ],
                types: {
                    data1: 'area'
                },
                colors: {
                    data1: '#4e54a8'
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                show: false
            },
            point: {
                show: false
            },
            axis: {
                x: {show:false},
                y: {show:false}
            }
        });

        c3.generate({
            bindto: '.ks-chart-orders-block',
            data: {
                columns: [
                    ['Revenue', 150, 200, 220, 280, 400, 160, 260, 400, 300, 400, 500, 420, 500, 300, 200, 100, 400, 600, 300, 360, 600],
                    ['Profit', 350, 300,  200, 140, 200, 30, 200, 100, 400, 600, 300, 200, 100, 50, 200, 600, 300, 500, 30, 200, 320]
                ],
                colors: {
                    'Revenue': '#f88528',
                    'Profit': '#81c159'
                }
            },
            point: {
                r: 5
            },
            grid: {
                y: {
                    show: true
                }
            }
        });

        // setTimeout(function () {
        //     new Noty({
        //         text: '<strong>Welcome to Kosmo Admin Template</strong>! <br> You successfully read this important alert message.',
        //         type   : 'information',
        //         theme  : 'mint',
        //         layout : 'topRight',
        //         timeout: 3000
        //     }).show();
        // }, 1500);

        var maplace = new Maplace({
            map_div: '#ks-payment-widget-table-and-map-map',
            controls_on_map: false
        });
        maplace.Load();
    });

    $('select.ks-select').select2();

        $('select.ks-select-placeholder-single').select2({
            placeholder: "Select a Date",
            allowClear: true
        });

        $('select.ks-select-placeholder-multiple').select2({
            placeholder: "Select a Product"
        });
})(jQuery);
</script>

<div class="ks-mobile-overlay"></div>

</body>
</html>