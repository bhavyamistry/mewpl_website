<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to Drnq</title>

	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	
	</style>
</head>
<body>
<?php echo validation_errors(); ?>
<form method="POST">
	 Date:<input type="date" name="date" placeholder="Enter date" required><br><br>
	Product:<select name="products" required>
	<option value="" disabled="" selected>Select</option>
	<?php
		$i=1;
	  foreach($data as $row)
	  {
	  echo "<option value='".$row->product_name."'>".$row->product_name."</option>";
	  $i++;
	  }
	  ?>
		</select>
	Size:<select name="size" required>
	<option value="" disabled="" selected>Select</option>
	<?php
		$i=1;
	  foreach($data2 as $row)
	  {
		echo "<option value='".$row->size."'>".$row->size."</option>";
	  	$i++;
	  }
	?>
		</select>
	Batch Number:<input type="text" name="batch_num" size="20" style="width:10%;" placeholder="Batch Number" required> 
	Qty:<input type="number" name="qty" min="0" placeholder="Qty" style="width: 5.5%;" required> <br><br>
	Crates:<input type="number" name="crates" min="0" placeholder="Crates" style="width: 5.5%" required>
	Films Used:<input type="number" name="films" min="0" placeholder="Films Used" style="width: 5.5%" required>
	CLR:<input type="number" name="clr" min="0" placeholder="CLR" style="width: 5.2%" required>
	FAT:<input type="number" name="fat" min="0" step=".00" placeholder="FAT" style="width: 5.2%" required>
	SNF:<input type="number" name="snf" min="0" placeholder="SNF" style="width: 5.2%" required>
	Acidity:<input type="number" name="acidity" min="0" placeholder="Acidity" style="width: 5.2%" required>
	MBRT(Hr):<input type="number" name="mbrt" min="0" placeholder="MBRT" style="width: 5.2%" required>
	Rate:<input type="number" name="rate" min="0" placeholder="rate" style="width: 5.2%" required><br><br>
	Adulteration Test<br><br>
	Neutralizer:<select id="Neutralizer" name="neutralizer">
		<option value="+VE">+VE</option>
		<option value="_VE">_VE</option>
	</select>
	Hydrogen Peroxide:<select id="hydrogen_peroxide" name="hydrogen_peroxide">
		<option value="+VE">+VE</option>
		<option value="_VE">_VE</option>
	</select>
	Detergent/Pulvarized:<select id="detergent" name="detergent" >
		<option value="+VE">+VE</option>
		<option value="_VE">_VE</option>
	</select>
	Starch:<select id="starch" name="starch">
		<option value="+VE">+VE</option>
		<option value="_VE">_VE</option>
	</select>
	Urea:<select id="urea" name="urea">
		<option value="+VE">+VE</option>
		<option value="_VE">_VE</option>
	</select>
	Sugar:<select id="sugar" name="sugar">
		<option value="+VE">+VE</option>
		<option value="_VE">_VE</option>
	</select>
	Boric Acid:<select id="boric_acid" name="boric_acid">
		<option value="+VE">+VE</option>
		<option value="_VE">_VE</option>
	</select>
	<br><br>
	<input type="submit" name="save">
</form>
</body>
</html>